package Question1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


class employee{
	int Id;
	String Name;
	public employee(int id, String name) {
		super();
		Id = id;
		Name = name;
	}	
}

public class Question1 {

	public static void main(String[] args) {
		
		ArrayList<employee> emplo = new ArrayList<employee>();
		emplo.add(new employee(105, "Tom"));
		emplo.add(new employee(124, "Tony"));
		emplo.add(new employee(132, "Stark"));
		
		System.out.println("Compartor ----");
		Comparator<employee> Idcompare = (E1,E2) -> {
			return (E1.Id == E2.Id) ? 1:(E1.Id > E2.Id) ? 0 : -1;			
		};
		Collections.sort(emplo, Idcompare);
		for( employee i : emplo ) {
			System.out.println( i.Id + " " + i.Name );
			
			System.out.println("Name compartor");
			Comparator<employee> Namecompare = (E1,E2) -> {
				return E1.Name.compareTo(E2.Name);		
			};
			Collections.sort(emplo , Namecompare);
			
			for( employee i1 : emplo) {
				System.out.println( i1.Id + " " + i1.Name );			
			}	
			
		}
	}

}

