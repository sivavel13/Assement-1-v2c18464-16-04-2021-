package Question9;

import java.util.LinkedList;

class Car{
	int ID;
	String Name;
	public Car(int iD, String name) {
		super();
		ID = iD;
		Name = name;
	}	
}

public class Question9 {

	public static void main(String[] args) {

		LinkedList<Car> carName = new LinkedList<Car>();
		carName.add(new Car(10, "Maruti"));
		carName.add(new Car(11, "aadi"));
		carName.add(new Car(12, "TATA"));
		
		for (Car i : carName) {
			System.out.println(i.Name + " " + i.ID);
		}
		int midele = carName.size()/2;
		carName.remove(midele);		
		System.out.println("Remove Middle");
		for (Car i : carName) {
			System.out.println(i.Name + " " + i.ID);
		
	}

}
}
