package Question10;

import java.util.ArrayList;
import java.util.Collections;

public class Question10 {

	public static void main(String[] args) {
		 ArrayList<String> arraylist = new ArrayList<String>();
		   arraylist.add("Adhi");
		   arraylist.add("Mahi");
		   arraylist.add("Vishva");
		   arraylist.add("Yasar");
		   
		   System.out.println("Before Sorting:");
		   for(String str: arraylist){
				System.out.println(str);
			}
		   Collections.sort(arraylist, Collections.reverseOrder());
		   System.out.println("ArrayList in descending order:");
		   for(String str: arraylist){
				System.out.println(str);
			}
	}

}
