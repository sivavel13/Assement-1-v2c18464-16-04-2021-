package Question6;

public class Question6 {

	public static void main(String[] args) {
			
	      String InputV = "MOM";
	      String reverse = "";
	 
	      int length = InputV.length();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	    	  reverse = reverse + InputV.charAt(i);
	 
	      if (InputV.equals(reverse))
	         System.out.println(InputV+" is a palindrome");
	      else
	         System.out.println(InputV+" is not a palindrome");
	}
}
